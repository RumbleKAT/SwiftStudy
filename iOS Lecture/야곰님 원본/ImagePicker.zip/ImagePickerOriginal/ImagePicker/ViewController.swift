//
//  ViewController.swift
//  ImagePicker
//
//  Created by yagom on 2017. 10. 18..
//  Copyright © 2017년 yagom. All rights reserved.
//

import UIKit

class ViewController: UIViewController, UIImagePickerControllerDelegate, UINavigationControllerDelegate {

    // MARK:- Properties
    let imagePicker: UIImagePickerController = UIImagePickerController()
    
    // MARK: IBOutlet
    @IBOutlet weak var imageView: UIImageView!
    
    // MARK:- Methods
    // MARK: Life Cycle
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.initializeImagePicker()
        
//        self.imageView.contentMode = UIViewContentMode.scaleAspectFit
//        self.imageView.contentMode = UIViewContentMode.scaleAspectFill
//        self.imageView.contentMode = UIViewContentMode.scaleToFill
    }
    
    // MARK: IBActions
    @IBAction func tapImageView(_ sender: UITapGestureRecognizer) {
        
        
        let alert: UIAlertController = UIAlertController(title: "소스 선택", message: "사진을 어디에서 가져올까요?", preferredStyle: UIAlertControllerStyle.actionSheet)
        // UIAlertControllerStyle.alert
        
        let cancelAction: UIAlertAction = UIAlertAction(title: "취소", style: UIAlertActionStyle.cancel, handler: nil)
       
        let photoLibraryAction: UIAlertAction = UIAlertAction(title: "사진앨범", style: UIAlertActionStyle.default) { (action: UIAlertAction) in
            self.imagePicker.sourceType = UIImagePickerControllerSourceType.photoLibrary
            self.present(self.imagePicker, animated: true) {
                print("이미지 피커 나타남 - 사진앨범")
            }
        }
        
        let cameraAction: UIAlertAction = UIAlertAction(title: "카메라", style: UIAlertActionStyle.default) { (action: UIAlertAction) in
            self.imagePicker.sourceType = UIImagePickerControllerSourceType.camera
            self.present(self.imagePicker, animated: true) {
                print("이미지 피커 나타남 - 카메라")
            }
        }
        
        alert.addAction(cancelAction)
        alert.addAction(photoLibraryAction)
        alert.addAction(cameraAction)
        
        self.present(alert, animated: true) {
            print("얼럿 나타남")
        }
    }
    
    // MARK: Custom Method
    func initializeImagePicker() {
        
        self.imagePicker.delegate = self
        self.imagePicker.sourceType = UIImagePickerControllerSourceType.photoLibrary
        self.imagePicker.allowsEditing = true  // false
    }
    
    
    // MARK: UIImagePickerControllerDelegate Method
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [String : Any]) {
        
        // 이 메서드 종료시에 꼭 실행할 코드는 defer 내부에 작성
        defer {
            self.dismiss(animated: true) {
                print("이미지 피커 사라짐")
            }
        }
        
        guard let editedImage: UIImage = info[UIImagePickerControllerEditedImage] as? UIImage else {
            print("이미지 정보 없음")
            return
        }
        
        self.imageView.image = editedImage
        
    }
    
    func imagePickerControllerDidCancel(_ picker: UIImagePickerController) {
        print("이미지 선택이 취소되었습니다")
        self.dismiss(animated: true) {
            print("이미지 피커 사라짐")
        }
    }
}

