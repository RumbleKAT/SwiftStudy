//
//  ImageDownloadViewController.swift
//  ImagePicker
//
//  Created by yagom on 2017. 10. 18..
//  Copyright © 2017년 yagom. All rights reserved.
//

import UIKit

class ImageDownloadViewController: UIViewController {

    
    // MARK:- Properties
    // MARK: IBOutlet
    @IBOutlet weak var imageView: UIImageView!
    @IBOutlet weak var urlField: UITextField!
    
    lazy var indicator: UIActivityIndicatorView = {
        let indicator: UIActivityIndicatorView = UIActivityIndicatorView(activityIndicatorStyle: UIActivityIndicatorViewStyle.whiteLarge)
        indicator.backgroundColor = UIColor.lightGray
        indicator.translatesAutoresizingMaskIntoConstraints = false
        return indicator
    }()
    
    // MARK:- Methods
    // MARK: Life Cycle
    override func viewDidLoad() {
        super.viewDidLoad()
    }

    // MARK: IBActions
    @IBAction func touchUpSyncDownloadButton(_ sender: UIButton) {
        self.urlField.endEditing(true)
        self.showActivityIndicator()
        
        guard let urlString: String = self.urlField.text, urlString.isEmpty == false else {
            return
        }
        
        guard let url = URL(string: urlString) else {
            return
        }
        
        do {
            let data = try Data(contentsOf: url)
            let image = UIImage(data: data)
            self.imageView.image = image
        } catch {
            print(error.localizedDescription)
        }
        
        self.hideActivityIndicator()
    }
    
    @IBAction func touchUpAsyncDownloadButton(_ sender: UIButton) {
        self.urlField.endEditing(true)
        self.showActivityIndicator()
        
        guard let urlString: String = self.urlField.text, urlString.isEmpty == false else {
            return
        }
        
        guard let url = URL(string: urlString) else {
            return
        }
        
        DispatchQueue.global().async {
            
            defer {
                DispatchQueue.main.async {
                    self.hideActivityIndicator()
                }
            }
            
            do {
                let data = try Data(contentsOf: url)
                let image = UIImage(data: data)
                
                DispatchQueue.main.async {
                    self.imageView.image = image
                }
            } catch {
                print(error.localizedDescription)
            }
        }
    }
    
    // MARK: Custom Method
    func showActivityIndicator() {
        self.view.addSubview(self.indicator)
        
        let safeAreaLayoutGuide: UILayoutGuide = self.view.safeAreaLayoutGuide
        
        self.indicator.centerXAnchor.constraint(equalTo: safeAreaLayoutGuide.centerXAnchor).isActive = true
        self.indicator.centerYAnchor.constraint(equalTo: safeAreaLayoutGuide.centerYAnchor).isActive = true
        
        indicator.startAnimating()
        
        UIApplication.shared.isNetworkActivityIndicatorVisible = true
    }
    
    func hideActivityIndicator() {
        
        self.indicator.stopAnimating()
        self.indicator.removeFromSuperview()
        
        UIApplication.shared.isNetworkActivityIndicatorVisible = false
    }
}
