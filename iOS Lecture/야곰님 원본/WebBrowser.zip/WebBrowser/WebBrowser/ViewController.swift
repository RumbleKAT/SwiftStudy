//
//  ViewController.swift
//  WebBrowser
//
//  Created by yagom on 2017. 10. 17..
//  Copyright © 2017년 yagom. All rights reserved.
//

import UIKit
import WebKit

class ViewController: UIViewController, UITextFieldDelegate, WKNavigationDelegate {
    
    // MARK: - Properties
    @IBOutlet weak var webView: WKWebView!
    var urlField: UITextField!
    
    // MARK: - Method
    // MARK: Life Cycle
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.webView.navigationDelegate = self
        
        self.makeURLFieldAndButton()
    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)

        if let appDelegate: AppDelegate = UIApplication.shared.delegate as? AppDelegate,
            let url: URL = appDelegate.lastURL {
            self.go(urlString: url.absoluteString)
        } else {
            self.go(urlString: "https://www.google.com")
        }
    }
    
    // MARK: Custom Method
    func makeURLFieldAndButton() {
        
        let urlView: UIView = UIView()
        urlView.translatesAutoresizingMaskIntoConstraints = false
        urlView.backgroundColor = UIColor.clear
        
        self.navigationItem.titleView = urlView

        urlView.widthAnchor.constraint(equalToConstant: UIScreen.main.bounds.width).isActive = true
        
        let field: UITextField = UITextField()
        field.borderStyle = UITextBorderStyle.roundedRect
        field.translatesAutoresizingMaskIntoConstraints = false
        field.keyboardType = UIKeyboardType.URL
        field.clearButtonMode = UITextFieldViewMode.whileEditing
        field.autocapitalizationType = UITextAutocapitalizationType.none
        field.delegate = self
        
        urlView.addSubview(field)
        
        field.topAnchor.constraint(equalTo: urlView.topAnchor, constant: 8).isActive = true
        field.bottomAnchor.constraint(equalTo: urlView.bottomAnchor, constant: -8).isActive = true
        field.leadingAnchor.constraint(equalTo: urlView.leadingAnchor, constant: 8).isActive = true
        
        self.urlField = field
        
        let button: UIButton = UIButton(type: UIButtonType.custom)
        button.translatesAutoresizingMaskIntoConstraints = false
        
        urlView.addSubview(button)
        
        button.setTitle("GO", for: UIControlState.normal)
        button.setTitleColor(UIColor.black, for: UIControlState.normal)
        button.addTarget(self, action: #selector(self.touchUpGoButton(sender:)), for: UIControlEvents.touchUpInside)
        
        button.setContentHuggingPriority(UILayoutPriority.defaultHigh, for: UILayoutConstraintAxis.horizontal)
        button.setContentCompressionResistancePriority(UILayoutPriority.required, for: UILayoutConstraintAxis.horizontal)
        
        button.leadingAnchor.constraint(equalTo: field.trailingAnchor, constant: 8).isActive = true
        button.centerYAnchor.constraint(equalTo: field.centerYAnchor).isActive = true
        button.trailingAnchor.constraint(equalTo: urlView.trailingAnchor, constant: -8).isActive = true
    }
    
    func go(urlString: String?) {
        guard let text: String = urlString, text.isEmpty == false else {
            print("URL을 입력해주세요")
            return
        }
        
        guard let url: URL = URL(string: text) else {
            print("잘못된 URL 형식")
            return
        }
        
        self.urlField.resignFirstResponder()
        
        let request = URLRequest(url: url)
        self.webView.load(request)
    }
    
    @objc func touchUpGoButton(sender: UIButton) {
        self.go(urlString: self.urlField.text)
    }
    
    // MARK: IBActions
    @IBAction func goBack(_ sender: UIBarButtonItem) {
        self.webView.goBack()
    }
    
    @IBAction func stop(_ sender: UIBarButtonItem) {
        self.webView.stopLoading()
        UIApplication.shared.isNetworkActivityIndicatorVisible = false
    }
    
    @IBAction func refresh(_ sender: UIBarButtonItem) {
        self.webView.reload()
    }
    @IBAction func goForward(_ sender: UIBarButtonItem) {
        self.webView.goForward()
    }
    
    // MARK: WKNavigationDelegate
    func webView(_ webView: WKWebView, didCommit navigation: WKNavigation!) {
        print("컨텐츠 요청을 합니다")
    }
    
    func webView(_ webView: WKWebView, didFinish navigation: WKNavigation!) {
        print("컨텐츠 로드가 끝났습니다")
        UIApplication.shared.isNetworkActivityIndicatorVisible = false
        self.urlField.text = webView.url?.absoluteString
        
        if let appDelegate: AppDelegate = UIApplication.shared.delegate as? AppDelegate {
            appDelegate.lastURL = webView.url
        }
    }
    
    func webView(_ webView: WKWebView, didStartProvisionalNavigation navigation: WKNavigation!) {
        print("컨텐츠 로드를 시작합니다")
        UIApplication.shared.isNetworkActivityIndicatorVisible = true
        self.urlField.text = webView.url?.absoluteString
    }
    
    // MARK: UITextFieldDelegate
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        self.go(urlString: textField.text)
        return true
    }
}

